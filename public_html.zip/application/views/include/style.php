<link href="<?php echo base_url('/inti/css/bootstrap.min.css'); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo base_url('/inti/css/default.css'); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo base_url('/inti/css/style.css'); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo base_url('/inti/css/plugin.css'); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo base_url('/inti/css/font-awesome.css'); ?>" rel="stylesheet" type="text/css">