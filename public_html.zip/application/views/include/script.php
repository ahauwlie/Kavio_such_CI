<script src="<?php echo base_url('/inti/js/jquery-3.2.1.min.js'); ?>" type="7e9a2b5499616e67c318e58a-text/javascript"></script>
<script src="<?php echo base_url('/inti/js/plugin.js'); ?>" type="7e9a2b5499616e67c318e58a-text/javascript"></script>
<script src="<?php echo base_url('/inti/js/custom-nav.js'); ?>" type="7e9a2b5499616e67c318e58a-text/javascript"></script>
<script src="<?php echo base_url('/inti/js/main.js'); ?>" type="7e9a2b5499616e67c318e58a-text/javascript"></script>
<script src="<?php echo base_url('/inti/js/rocket-loader.min.js'); ?>" data-cf-settings="7e9a2b5499616e67c318e58a-|49" defer=""></script>