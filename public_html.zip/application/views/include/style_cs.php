<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,900" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url('/inti/dist/css/bootstrap.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/inti/dist/css/all.css'); ?>"           
    integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" 
    crossorigin="anonymous">
<link rel="stylesheet" href="<?php echo base_url('/inti/dist/css/themeimports.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/inti/dist/css/style.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/inti/dist/css/styleselector.css'); ?>">