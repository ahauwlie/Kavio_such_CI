<header id="inner-navigation">
	<nav class="navbar navbar-default navbar-fixed-top navbar-sticky-function navbar-arrow">
		<div class="container">
			<div class="logo pull-left">
				<h1><a href="index-2.html"><img src="<?php echo base_url('/inti/images/'); ?>" alt="logo yakk!"></a></h1>
			</div>
			<div id="navbar" class="navbar-nav-wrapper text-center">
				<ul class="nav navbar-nav navbar-right" id="responsive-menu">
					<li class="active">
						<a href="<?php echo site_url('Home'); ?>">Home</a>
					</li>
					<li>
						<a href="#">Pages <i class="fa fa-angle-down"></i></a>
						<ul>
							<li><a href="about-us.html">About Us</a></li>
							<li><a href="error.html">Error Page</a></li>
							<li>
								<a href="#">Detail Page</a>
								<ul>
									<li><a href="blog-details.html">Detail 1</a></li>
									<li><a href="blog-details1.html">Detail 2</a></li>
								</ul>
							</li>
							<li><a href="author.html">Author Page</a></li>
							<li>
								<a href="#">Category</a>
								<ul>
									<li><a href="category.html">Category Lists</a></li>
									<li><a href="category-detail.html">Category Detail</a></li>
								</ul>
							</li>
							<li>
								<a href="#">Tags</a>
								<ul>
									<li><a href="tag.html">Tag Lists</a></li>
									<li><a href="tag-detail.html">Tag Detail</a></li>
								</ul>
							</li>
							<li><a href="faq.html">Faq</a></li>
							<li><a href="coming-soon.html">Coming Soon</a></li>
						</ul>
					</li>
					<li>
						<a href="#">Dashboard <i class="fa fa-angle-down"></i></a>
						<ul>
							<li><a href="dashboard.html">Dashboard</a></li>
							<li><a href="dashboard-my-profile.html">Dashboard Profile</a></li>
							<li><a href="dashboard-booking.html">Dashboard Bookings</a></li>
							<li><a href="dashboard-history.html">Dashboard History</a></li>
							<li><a href="dashboard-list.html">Dashboard Listing</a></li>
							<li><a href="dashboard-addtour.html">Dashboard Add Tour</a></li>
							<li><a href="dashboard-reviews.html">Dashboard Reviews</a></li>
						</ul>
					</li>
					<li><a href="contact-us.html">Contact Us</a></li>
					<li><a href="#search" class="mt_search"><i class="fa fa-search"></i></a></li>
				</ul>
			</div>
		</div>
		<div id="slicknav-mobile"></div>
	</nav>
</header>