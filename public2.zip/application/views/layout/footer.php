<footer id="mt_footer" class="mt_footer_style1">
	<div class="container">
		<div class="mt_footer_col">
			<div class="row">
				<div class="col-md-3 col-sm-6 col-xs-12">
					<div class="mt_footer_about">
						<h2><a href="#">Love2Share</a></h2>
						<p>Sedikit kisahin Love2share aja ka, atau lu kasih moto apa gitu wkwkwkwk
						</p>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12">
					<div class="mt_footer_list">
						<h3>Quick Links</h3>
						<ul class="footer-quick-links-4">
							<li><a href="#"><i class="fa fa-angle-right"></i> January</a></li>
							<li><a href="#"><i class="fa fa-angle-right"></i> February</a></li>
							<li><a href="#"><i class="fa fa-angle-right"></i> March</a></li>
							<li><a href="#"><i class="fa fa-angle-right"></i> April</a></li>
							<li><a href="#"><i class="fa fa-angle-right"></i> May</a></li>
							<li><a href="#"><i class="fa fa-angle-right"></i> June</a></li>
							<li><a href="#"><i class="fa fa-angle-right"></i> July</a></li>
							<li><a href="#"><i class="fa fa-angle-right"></i> August</a></li>
							<li><a href="#"><i class="fa fa-angle-right"></i> September</a></li>
							<li><a href="#"><i class="fa fa-angle-right"></i> October</a></li>
							<li><a href="#"><i class="fa fa-angle-right"></i> November</a></li>
							<li><a href="#"><i class="fa fa-angle-right"></i> December</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12">
					<div class="mt_footer_newsletter">
						<h3>Newsletter</h3>
						<div class="mailpoet_form">
							<form target="_self" method="post" action="https://cyclonethemes.com/demo/html/suchana/email" novalidate="">
								<label>Email Address:</label>
								<input type="email" class="mailpoet_text" name="mail" title="Email" placeholder="Please specify a valid email address.">
								<div class="blog-button">
									<button class="btn-blog">Subscribe</button>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12">
					<div class="mt_footer_gallery">
						<h3>Amazing Gallery</h3>
						<div class="row">
							<div class="col-sm-4 col-xs-6"><a href="#"><img src="<?php echo base_url('/inti/images/insta/insta_01.jpg'); ?>" alt="Image"></a></div>
							<div class="col-sm-4 col-xs-6"><a href="#"><img src="<?php echo base_url('/inti/images/insta/insta_02.jpg'); ?>" alt="Image"></a></div>
							<div class="col-sm-4 col-xs-6"><a href="#"><img src="<?php echo base_url('/inti/images/insta/insta_03.jpg'); ?>" alt="Image"></a></div>
							<div class="col-sm-4 col-xs-6"><a href="#"><img src="<?php echo base_url('/inti/images/insta/insta_04.jpg'); ?>" alt="Image"></a></div>
							<div class="col-sm-4 col-xs-6"><a href="#"><img src="<?php echo base_url('/inti/images/insta/insta_05.jpg'); ?>" alt="Image"></a></div>
							<div class="col-sm-4 col-xs-6"><a href="#"><img src="<?php echo base_url('/inti/images/insta/insta_06.jpg'); ?>" alt="Image"></a></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="mt_footer_copy">
			<div class="copy_txt pull-left">
				<p class="mar-0">Develop by <a href="https://www.instagram.com/congacongz/">GOX team</a></p>
			</div>
			<div class="follow_us pull-right">
				<ul class="social_icons">
					<li><a href="#"> <i class="fa fa-facebook"></i></a></li>
					<li><a href="#"><i class="fa fa-twitter"></i></a></li>
					<li><a href="#"><i class="fa fa-instagram"></i></a></li>
					<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
</footer>