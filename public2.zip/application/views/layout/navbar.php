<header id="inner-navigation">
	<nav class="navbar navbar-default navbar-fixed-top navbar-sticky-function navbar-arrow">
		<div class="container">
			<div class="logo pull-left">
				<h1><a href="index-2.html"><img src="<?php echo base_url('/inti/images/'); ?>" alt="logo yakk!"></a></h1>
			</div>
			<div id="navbar" class="navbar-nav-wrapper text-center">
				<ul class="nav navbar-nav navbar-right" id="responsive-menu">
					<li class="active">
						<a href="<?php echo site_url('Home'); ?>">Home</a>
					</li>
					<li><a href="<?php echo site_url('Home/contact_us'); ?>">Contact Us</a></li>
					<li><a href="#search" class="mt_search"><i class="fa fa-search"></i></a></li>
				</ul>
			</div>
		</div>
		<div id="slicknav-mobile"></div>
	</nav>
</header>